library(testthat)
library(tailr)

test_check("tailr")
