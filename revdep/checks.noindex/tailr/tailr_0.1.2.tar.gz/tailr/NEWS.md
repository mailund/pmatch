# tailr 0.1.2

* The transformation function do no longer use !!! and this seems
  to solve problems with CMD CHECK in downstream packages.
* the srcref attribute gets set (to the source of the input function) in
  loop_transform.

# tailr 0.1.1

* Handles functions when they are local variables.

# tailr 0.1.0

* Initial release.
